var db = firebase.firestore();
const innertbody = document.getElementById("innertbody");
getUser();
      get_appointments('abc')
      .then((result) => {
          console.log(result);
          //addFilterTable()
      }).catch((err) => {
          alert(err.message)
      });    
      
    
    
    function get_appointments(uid) {
        return new Promise((resolve, reject) => {
            innertbody.innerHTML = '';
            db.collection("booking_history")
            .get()
            .then((querySnapshot) => {
                if (!querySnapshot.empty) {
                    var i = 1;
                    querySnapshot.forEach((doc) => {
                        // doc.data() is never undefined for query doc snapshots
                        console.log(doc.id, " => ", doc.data());
                        var row = `<tr class="col-form-label col-form-label-sm text-white ">
                            <td>${i}</td>
                            <td>${dateToTimestamp(doc.data().dateBooked)}</td>
                            <td>
                                <p class="card-text rounded border bg-light text-dark p-1 d-inline-flex shadow-sm w-100 d-flex justify-content-center">
                                    <small class="tag font-weight-bold">
                                    ${dateFunction(doc.data().dateBooked)}
                                    </small>
                                </p>
                            </td>
                            <td>${dateSuffix(doc.data().slotBooked)}</td>
                            <td>${doc.data().sportName}</td>
                            <td>
                                <p class="card-text rounded border bg-light text-dark p-1 d-inline-flex shadow-sm w-100 d-flex ">
                                    <small class="tag font-weight-bold">
                                    <i class="fas fa-map-marker-alt"></i> ${doc.data().venueName}
                                    </small>
                                </p>
                            
                            </td>
                            <td>${doc.data().pricePaid}</td>
                            <td class="text-center">
                                <div class="badge badge-primary text-wrap text-center" >
                                    ${checkMembership(doc.data().uid, doc.data().venueName)}
                                </div>
                            </td>
                        </tr>`
                        console.log(); 
                        i++;
                        innertbody.innerHTML = innertbody.innerHTML + row;
                    });
                    if ( uid ) {
                        resolve("Stuff worked!");
                    } else {
                        reject(Error("It didn't work!"));
                    }
                } else {
                    console.log('querySnapshot not exist!');
                }
                
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
        });
    }
    function addFilterTable() {
      $(document).ready( function () {
          // Setup - add a text input to each footer cell
    $('#example thead tr').clone(true).appendTo( '#example thead' );
    $('#example thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();
        if (i === 0 || i === 1) {

        } else if (i === 4 ) {
            $(this).html( '<input id="sports" type="text" placeholder="Search '+title+'" />' );
        } else {
            $(this).html( '<input id="" type="text" placeholder="Search '+title+'" />' );
        }
        
        $( 'input', this ).on( 'keyup change', function () {
            if ( table.column(i).search() !== this.value ) {
                table
                    .column(i)
                    .search( this.value )
                    .draw();
            }
        } );
    } );
        var table = $('#example').DataTable({
            responsive: true,
            order: [[ 1, 'des' ]],
            orderCellsTop: true,
            fixedHeader: true,
            "fnRowCallback" : function(nRow, aData, iDisplayIndex){
                $("td:first", nRow).html(iDisplayIndex +1);
                return nRow;
            },
            "columnDefs": [
                { "searchable": false, "targets": [0, 1] }  // Disable search on first and last columns
              ]
            /*,
            "autoWidth":false,
            "columnDefs": [
                { "width": "5%", "targets": 0 },
                { "width": "15%", "targets": 1 },
                { "width": "5%", "targets": 2 },
                { "width": "5%", "targets": 3 },
                { "width": "10%", "targets": 4 },
                { "width": "15%", "targets": 5 },
                { "width": "5%", "targets": 6 },
                { "width": "20%", "targets": 7 }
            ]*/
        });
      });
    }
    
    


      function timeConverter(UNIX_timestamp){
        if (UNIX_timestamp){
        var a = new Date(UNIX_timestamp);
        console.log(a);
            var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var year = a.getFullYear();
            var month = months[a.getMonth()];
            var date = a.getDate();
            var nowHour = a.getHours();
            var nowMinutes = a.getMinutes();
            var sec = a.getSeconds();
      
          var suffix = nowHour >= 12 ? "PM" : "AM";
          nowHour = (suffix == "PM" & (nowHour > 12 & nowHour < 24)) ? (nowHour - 12) : nowHour;
          nowHour = nowHour == 0 ? 12 : nowHour;
          nowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
          var currentTime = date + ' ' + month + ' ' + year + ' - ' + nowHour + ":" + nowMinutes + ' ' + suffix;
                  
          return currentTime
        } else {
          return "-";
        }
      }

      function dateFunction(UNIX_timestamp){
        if (UNIX_timestamp){
        var a = new Date(UNIX_timestamp);
        console.log(a);
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            var year = a.getFullYear();
            var month = months[a.getMonth()];
            var date = a.getDate();
            var nowHour = a.getHours();
            var nowMinutes = a.getMinutes();
            var sec = a.getSeconds();
      
          var suffix = nowHour >= 12 ? "PM" : "AM";
          nowHour = (suffix == "PM" & (nowHour > 12 & nowHour < 24)) ? (nowHour - 12) : nowHour;
          nowHour = nowHour == 0 ? 12 : nowHour;
          nowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
          var currentTime = date + ' ' + month + ' ' + year;
                  
          return currentTime
        } else {
          return "-";
        }
      }
      
function dateSuffix(params) {
    if(isDate(params)){
        var a = new Date(params);
        console.log(a);
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        var year = a.getFullYear();
        var month = months[a.getMonth()];
        var date = a.getDate();
        var nowHour = a.getHours();
        var nowMinutes = a.getMinutes();
        var sec = a.getSeconds();
      
        var suffix = nowHour >= 12 ? "PM" : "AM";
        nowHour = (suffix == "PM" & (nowHour > 12 & nowHour < 24)) ? (nowHour - 12) : nowHour;
        nowHour = nowHour == 0 ? 12 : nowHour;
        nowMinutes = nowMinutes < 10 ? "0" + nowMinutes : nowMinutes;
        var currentTime = nowHour + ":" + nowMinutes + ' ' + suffix;          
        
        return currentTime

    } else {
          //Example of use:
          var something = params;
          something = something.insert(2, ":");
          something = something.substring(0, 5);
          console.log(something)
          return tConvert(something)
    }
}

String.prototype.insert = function(index, string) {
    if (index > 0) {
      return this.substring(0, index) + string + this.substr(index);
    }
  
    return string + this;
};

function tConvert (time) {
    // Check correct time format and split into components
    time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];
  
    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join (''); // return adjusted time or original string
  }

function dateToTimestamp(d) {
    if (d){
        var a = new Date(d);
        console.log(a);
    }    
    console.log(a.getTime());
    return a.getTime()
}      

function isDate(date) {
    return (new Date(date) !== "Invalid Date") && !isNaN(new Date(date));
}

var usersArray = []

function getUser() {
    return new Promise((resolve, reject) => {
        let status = ''
        const userRef = db.collection("userProfile")
        userRef.get().then((querySnapshot) => {
            usersArray = querySnapshot.docs.map((doc) => {
                return { id: doc.id, ...doc.data() }
            })
            //console.log(tempDoc)
            //usersArray.push(tempDoc)
            console.log(usersArray);
        })
        
        /*userRef.get().then((doc) => {
            // doc.data() is never undefined for query doc snapshots
            if (doc.exists) {
                console.log("Document data:", doc.data());
                status = "Member"
                if ( uid ) {
                    resolve(status);
                } else {
                    reject(Error("It didn't work!"));
                }
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
                status = "Not a member"
                if ( uid ) {
                    resolve(status);
                } else {
                    reject(Error("It didn't work!"));
                }
            }
            
        })*/
    });
}

function checkMembership(user_id, venue) {
    console.log('checkArray');
    console.log(usersArray.length);
    /*for (var index = 0; index < usersArray.length; index++) {
        console.log(usersArray[index].id);
    }*/
    // grab the Array item which matchs the id "2"

    var item = usersArray.find(item => item.id === user_id);

    console.log(item);
    if (item) {
        if (item.clubA === venue || item.clubB === venue || item.clubC === venue) {
            return `${item.fullName} is a Member`
        } else {
            return `${item.fullName} is not a member`
        }
    } else {
        return "Not a member"
    }
    

    /* print
    console.log(item.id);
    console.log(item.uid);
    */
}

function addtext() {
    document.getElementById('sports').value = "Football"
}